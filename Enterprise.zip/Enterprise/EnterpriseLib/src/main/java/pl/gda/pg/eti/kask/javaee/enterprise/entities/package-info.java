@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.eti.pg.gda.pl/kask/javaee/books", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package pl.gda.pg.eti.kask.javaee.enterprise.entities;
